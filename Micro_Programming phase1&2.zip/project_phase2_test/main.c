#include <stdio.h>  
#include <stdlib.h>  
#include <math.h>  
#include <string.h>  
#include <time.h>  

#ifdef _WIN32  
#include <windows.h> // For Sleep() function on Windows  
#else  
#include <unistd.h>  // For usleep() function on Unix-like systems (if available)  
#endif  

#define SAMPLE_RATE 50000  
#define DURATION_SEC 1.0  

// Simulated function to mimic ADC readings  
uint16_t adc_read() {  
    return rand() % 4096; // Generate a random value between 0 and 4095  
}  

// Function to estimate frequency using zero-crossing rate  
float estimate_freq_zcr(float *signal, int num_samples) {  
    int zero_crossings = 0;  
    for (int i = 1; i < num_samples; i++) {  
        if ((signal[i - 1] >= 2048 && signal[i] < 2048) || (signal[i - 1] < 2048 && signal[i] >= 2048)) {   
            zero_crossings++;  
        }  
    }  
    return zero_crossings < 2 ? 0.0 : SAMPLE_RATE / ((float)zero_crossings / 2);  
}  

// Function to calculate the percentage error  
float calculate_percentage_error(float true_freq, float estimated_freq) {  
    return fabs(true_freq - estimated_freq) / true_freq * 100;  
}  

// Function to run tests for different frequencies  
void run_tests(float *frequencies, int num_frequencies, int trials, FILE *output_file) {  
    for (int i = 0; i < num_frequencies; i++) {  
        float freq = frequencies[i];  
        printf("\nTesting Frequency: %.2f Hz\n", freq);  
        fprintf(output_file, "\nTesting Frequency: %.2f Hz\n", freq);  
        float *signal = (float *)malloc((int)(SAMPLE_RATE * DURATION_SEC) * sizeof(float));  

        for (int j = 0; j < trials; j++) {  
            int num_samples = (int)(SAMPLE_RATE * DURATION_SEC);  

            // Read samples from the simulated ADC  
            for (int k = 0; k < num_samples; k++) {  
                signal[k] = (float)adc_read(); // Simulated ADC value  
                #ifdef _WIN32  
                Sleep((int)(1000.0 / SAMPLE_RATE)); // Sleep in milliseconds for Windows  
                #else  
                // Busy-wait loop as an alternative if usleep is unavailable  
                for (volatile int wait = 0; wait < 1000; wait++); // Adjust loop as necessary for timing  
                #endif  
            }  

            float estimated_freq_zcr = estimate_freq_zcr(signal, num_samples);  
            float error = calculate_percentage_error(freq, estimated_freq_zcr);  
            printf("  Estimated Frequency = %.2f Hz, Error = %.5f%%\n", estimated_freq_zcr, error);  
            fprintf(output_file, "  Estimated Frequency = %.2f Hz, Error = %.5f%%\n", estimated_freq_zcr, error);  
        }  

        free(signal);  
    }  
}  

int main() {  
    srand(time(NULL)); // Seed for random number generation  

    float frequencies_to_test[] = {50, 100, 150, 200, 250, 300, 400, 500, 750, 1000, 1300, 1600, 2000};  
    int trials_per_frequency = 15;  
    int num_frequencies = sizeof(frequencies_to_test) / sizeof(frequencies_to_test[0]);  

    // Open output file for writing  
    FILE *output_file = fopen("output.txt", "w");  
    if (output_file == NULL) {  
        fprintf(stderr, "Error opening output file.\n");  
        return 1;  
    }  

    run_tests(frequencies_to_test, num_frequencies, trials_per_frequency, output_file);  

    fclose(output_file); // Close the output file  
    return 0;  
}