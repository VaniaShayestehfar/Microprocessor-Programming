#include <stdio.h>  
#include <stdlib.h>  
#include <math.h>  

#define SAMPLE_RATE 10000  
#define EXPECTED_FREQ 1000.0  
#define DEBUG 1  
#define ERROR_THRESHOLD 0.5  
#define NOISE_THRESHOLD 0.02  

float estimate_frequency_zero_crossing(float *signal, int num_samples) {  
    int zero_crossings = 0;  
    float last_crossing_index = 0;  
    float total_period = 0;  

    for (int i = 1; i < num_samples; i++) {  
        if (fabs(signal[i]) < NOISE_THRESHOLD && fabs(signal[i - 1]) < NOISE_THRESHOLD) {  
            continue;  
        }  

        if ((signal[i - 1] < 0 && signal[i] >= 0) || (signal[i - 1] >= 0 && signal[i] < 0)) {  
            zero_crossings++;  
            float crossing_index = i - 1 + (fabs(signal[i - 1]) / (fabs(signal[i - 1]) + fabs(signal[i])));  
            total_period += (crossing_index - last_crossing_index);  
            last_crossing_index = crossing_index;  

            if (DEBUG) {  
                printf("Zero crossing detected at sample index %.2f\n", crossing_index);  
            }  
        }  
    }  

    if (zero_crossings < 2) {  
        printf("Error: Not enough zero crossings to estimate frequency.\n");  
        return -1;  
    }  

    float avg_period = (total_period / (zero_crossings - 1)) / SAMPLE_RATE;  
    float frequency = 1.0 / (2 * avg_period);  

    return frequency;  
}  

void validate_frequency(float estimated_freq, float expected_freq) {  
    float error = fabs(estimated_freq - expected_freq);  
    float error_percentage = (error / expected_freq) * 100;  

    printf("Estimated Frequency: %.2f Hz\n", estimated_freq);  
    printf("Expected Frequency: %.2f Hz\n", expected_freq);  
    printf("Error: %.2f Hz (%.2f%%)\n", error, error_percentage);  

    if (error_percentage < ERROR_THRESHOLD) {  
        printf("Validation PASSED: Frequency estimation is within acceptable limits (error < 0.5%%).\n");  
    } else {  
        printf("Validation FAILED: Frequency estimation is outside acceptable limits (error >= 0.5%%).\n");  
    }  
}  

int main() {  
    int num_samples = 100000;  
    float signal[num_samples];  
    for (int i = 0; i < num_samples; i++) {  
        signal[i] = sin(2 * M_PI * EXPECTED_FREQ * i / SAMPLE_RATE) + 0.01 * ((float)rand() / RAND_MAX - 0.5);  
    }  

    float estimated_freq = estimate_frequency_zero_crossing(signal, num_samples);  

    if (estimated_freq > 0) {  
        validate_frequency(estimated_freq, EXPECTED_FREQ);  
    }  

    return 0;  
}