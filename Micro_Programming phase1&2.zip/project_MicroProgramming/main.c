#include <stdio.h>  
#include <stdlib.h>  
#include <math.h>  
#include <string.h>  
#include "pico/stdlib.h"  
#include "hardware/adc.h"  
#include "hardware/pwm.h"  

#define SAMPLE_RATE 50000  
#define DURATION_SEC 1.0  
#define INPUT_PIN 26 // ADC pin (GPIO 26)  
#define OUTPUT_PIN 15 // PWM pin for output (GPIO 15)  

float estimate_freq_zcr(float *signal, int num_samples) {  
    int zero_crossings = 0;  
    for (int i = 1; i < num_samples; i++) {  
        if ((signal[i - 1] >= 0 && signal[i] < 0) || (signal[i - 1] < 0 && signal[i] >= 0)) {  
            zero_crossings++;  
        }  
    }  
    return zero_crossings < 2 ? 0.0 : 1.0 / ((float)num_samples / zero_crossings * 2);  
}  

float calculate_percentage_error(float true_freq, float estimated_freq) {  
    return fabs(true_freq - estimated_freq) / true_freq * 100;  
}  

void run_tests(float *frequencies, int num_frequencies, int trials) {  
    for (int i = 0; i < num_frequencies; i++) {  
        float freq = frequencies[i];  
        printf("\nTesting Frequency: %.2f Hz\n", freq);  
        float errors[trials];  

        for (int j = 0; j < trials; j++) {  
            int num_samples = (int)(SAMPLE_RATE * DURATION_SEC);  
            float *signal = (float *)malloc(num_samples * sizeof(float));  

            // Read samples from the ADC  
            for (int k = 0; k < num_samples; k++) {  
                adc_select_input(0); // Select ADC channel 0 (GPIO 26)  
                uint16_t raw_value = adc_read(); // Read the ADC value  
                signal[k] = (float)raw_value; // Convert to float  
                sleep_us((1e6 / SAMPLE_RATE)); // Wait for the next sample  
            }  

            float estimated_freq_zcr = estimate_freq_zcr(signal, num_samples);  
            float estimated_freq = estimated_freq_zcr; // Use ZCR estimate for now  

            errors[j] = calculate_percentage_error(freq, estimated_freq);  
            printf("  Estimated Frequency = %.2f Hz, Error = %.5f%%\n", estimated_freq, errors[j]);  

            // Output estimated frequency as PWM (0-255 scaling)  
            uint8_t pwm_value = (uint8_t)(estimated_freq / 2000.0 * 255);  
            pwm_set_gpio_level(OUTPUT_PIN, pwm_value);  

            free(signal);  
        }  
    }  
}  

int main() {  
    stdio_init_all();  
    adc_init(); // Initialize the ADC  
    adc_gpio_init(INPUT_PIN);  
    adc_select_input(0); // Select ADC channel 0 (GPIO 26)  

    gpio_set_function(OUTPUT_PIN, GPIO_FUNC_PWM);  
    uint slice_num = pwm_gpio_to_slice_num(OUTPUT_PIN);  
    pwm_set_wrap(slice_num, 255); // Set the PWM range (0-255)  
    pwm_set_enabled(slice_num, true); // Enable the PWM output  

    float frequencies_to_test[] = {50, 100, 150, 200, 250, 300, 400, 500, 750, 1000, 1300, 1600, 2000};  
    int trials_per_frequency = 15;  
    int num_frequencies = sizeof(frequencies_to_test) / sizeof(frequencies_to_test[0]);  

    run_tests(frequencies_to_test, num_frequencies, trials_per_frequency);  

    return 0;  
}